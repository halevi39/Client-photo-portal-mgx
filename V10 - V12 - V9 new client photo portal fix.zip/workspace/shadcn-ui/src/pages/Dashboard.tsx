import { User } from '@/lib/auth';
import FileManager from '@/components/FileManager';

interface DashboardProps {
  user: User;
  onLogout: () => void;
}

export default function Dashboard({ user, onLogout }: DashboardProps) {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-3 sm:px-4 lg:px-6 py-4 sm:py-6">
        <FileManager user={user} onLogout={onLogout} />
      </div>
    </div>
  );
}