import LoginForm from '@/components/LoginForm';
import { User } from '@/lib/auth';

interface LoginProps {
  onLogin: (user: User) => void;
}

export default function Login({ onLogin }: LoginProps) {
  return <LoginForm onLogin={onLogin} />;
}