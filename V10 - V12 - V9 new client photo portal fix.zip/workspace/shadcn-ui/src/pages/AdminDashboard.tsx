import { useState, useEffect } from 'react';
import { AuthService, User } from '@/lib/auth';
import { FileStorageService, FileMetadata } from '@/lib/fileStorage';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import AdminUserManagement from '@/components/AdminUserManagement';
import ClientFileViewer from '@/components/ClientFileViewer';
import { Users, Images, HardDrive, LogOut, User as UserIcon, Eye } from 'lucide-react';
import { formatBytes } from '@/lib/utils';

interface AdminDashboardProps {
  user: User;
  onLogout: () => void;
}

export default function AdminDashboard({ user, onLogout }: AdminDashboardProps) {
  console.log('AdminDashboard rendering with user:', user);
  
  const [clients, setClients] = useState<User[]>([]);
  const [allFiles, setAllFiles] = useState<FileMetadata[]>([]);
  const [selectedClient, setSelectedClient] = useState<User | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    console.log('AdminDashboard useEffect triggered, user:', user);
    if (user?.role === 'admin') {
      try {
        loadData();
      } catch (err) {
        console.error('Error loading admin data:', err);
        setError('Failed to load dashboard data');
      }
    }
  }, [user]);

  const loadData = () => {
    console.log('Loading admin dashboard data...');
    try {
      const clientList = AuthService.getAllClients();
      console.log('Loaded clients:', clientList);
      setClients(clientList);
      
      const files = FileStorageService.getAllFiles();
      console.log('Loaded files:', files);
      setAllFiles(files);
    } catch (err) {
      console.error('Error in loadData:', err);
      setError('Failed to load data');
    }
  };

  const getClientStats = (clientId: string) => {
    const clientFiles = allFiles.filter(f => f.clientId === clientId);
    const totalSize = clientFiles.reduce((sum, file) => sum + file.size, 0);
    return {
      fileCount: clientFiles.length,
      totalSize
    };
  };

  const getTotalStats = () => {
    const totalFiles = allFiles.length;
    const totalSize = allFiles.reduce((sum, file) => sum + file.size, 0);
    const clientsWithFiles = new Set(allFiles.map(f => f.clientId)).size;
    return {
      totalFiles,
      totalSize,
      clientsWithFiles
    };
  };

  console.log('AdminDashboard render check - user:', user, 'role:', user?.role);

  if (!user || user.role !== 'admin') {
    console.log('Access denied - user:', user);
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-red-600 mb-4">Access Denied</h1>
          <p className="text-gray-600">You don't have permission to access this page.</p>
          <p className="text-sm text-gray-500 mt-2">User: {user ? JSON.stringify(user) : 'null'}</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-red-600 mb-4">Error</h1>
          <p className="text-gray-600">{error}</p>
          <Button onClick={() => { setError(null); loadData(); }} className="mt-4">
            Retry
          </Button>
        </div>
      </div>
    );
  }

  const stats = getTotalStats();
  console.log('Dashboard stats:', stats);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
              <Badge variant="default">Administrator</Badge>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <UserIcon className="h-4 w-4" />
                <span>{user.name}</span>
              </div>
              <Button variant="outline" onClick={onLogout}>
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="users">User Management</TabsTrigger>
            <TabsTrigger value="clients">Client Files</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Files</CardTitle>
                  <Images className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.totalFiles}</div>
                  <p className="text-xs text-muted-foreground">
                    Across all clients
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Clients</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{clients.length}</div>
                  <p className="text-xs text-muted-foreground">
                    {stats.clientsWithFiles} with files
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Storage</CardTitle>
                  <HardDrive className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{formatBytes(stats.totalSize)}</div>
                  <p className="text-xs text-muted-foreground">
                    Used storage space
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Client Overview */}
            <Card>
              <CardHeader>
                <CardTitle>Client Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {clients.map(client => {
                    const clientStats = getClientStats(client.id);
                    return (
                      <div key={client.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div className="p-2 bg-blue-100 rounded-full">
                            <UserIcon className="h-4 w-4 text-blue-600" />
                          </div>
                          <div>
                            <h4 className="font-semibold">{client.name}</h4>
                            <p className="text-sm text-gray-600">@{client.username}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-4">
                          <div className="text-right">
                            <div className="flex items-center space-x-4">
                              <div className="text-sm">
                                <span className="font-semibold">{clientStats.fileCount}</span> files
                              </div>
                              <div className="text-sm">
                                <span className="font-semibold">{formatBytes(clientStats.totalSize)}</span>
                              </div>
                            </div>
                          </div>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setSelectedClient(client)}
                            disabled={clientStats.fileCount === 0}
                          >
                            <Eye className="h-4 w-4 mr-2" />
                            View Files
                          </Button>
                        </div>
                      </div>
                    );
                  })}
                  
                  {clients.length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      <Users className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                      <p>No client accounts created yet</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users">
            <AdminUserManagement />
          </TabsContent>

          <TabsContent value="clients" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Client File Management</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {clients.map(client => {
                    const clientStats = getClientStats(client.id);
                    return (
                      <div key={client.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div className="p-2 bg-blue-100 rounded-full">
                            <UserIcon className="h-4 w-4 text-blue-600" />
                          </div>
                          <div>
                            <h4 className="font-semibold">{client.name}</h4>
                            <p className="text-sm text-gray-600">Username: {client.username}</p>
                            <p className="text-sm text-gray-500">
                              {clientStats.fileCount} files • {formatBytes(clientStats.totalSize)}
                            </p>
                          </div>
                        </div>
                        <Button
                          variant="outline"
                          onClick={() => setSelectedClient(client)}
                          disabled={clientStats.fileCount === 0}
                        >
                          <Eye className="h-4 w-4 mr-2" />
                          {clientStats.fileCount === 0 ? 'No Files' : 'View Files'}
                        </Button>
                      </div>
                    );
                  })}
                  
                  {clients.length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      <Users className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                      <p>No client accounts available</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Client File Viewer Modal */}
      {selectedClient && (
        <ClientFileViewer
          client={selectedClient}
          onClose={() => setSelectedClient(null)}
        />
      )}
    </div>
  );
}