import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { FileMetadata } from '@/lib/fileStorage';
import { Eye, Download, Edit, Trash2, Image, MoreVertical } from 'lucide-react';
import { formatBytes } from '@/lib/utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface PhotoListProps {
  files: FileMetadata[];
  selectedFiles: string[];
  onFileSelect: (fileId: string, selected: boolean) => void;
  onPreview: (file: FileMetadata) => void;
  onRename: (file: FileMetadata) => void;
  onDownload: (fileId: string) => void;
  onDelete: (fileId: string) => void;
}

export default function PhotoList({
  files,
  selectedFiles,
  onFileSelect,
  onPreview,
  onRename,
  onDownload,
  onDelete
}: PhotoListProps) {
  if (files.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500">
        <div className="text-6xl mb-4">📷</div>
        <h3 className="text-lg font-semibold mb-2">No photos uploaded yet</h3>
        <p>Upload your first photos to get started</p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {/* Header - Hidden on mobile */}
      <div className="hidden md:grid grid-cols-12 gap-4 p-3 bg-gray-50 rounded-lg text-sm font-medium text-gray-700">
        <div className="col-span-1">Select</div>
        <div className="col-span-1">Preview</div>
        <div className="col-span-4">Name</div>
        <div className="col-span-2">Size</div>
        <div className="col-span-2">Upload Date</div>
        <div className="col-span-2">Actions</div>
      </div>

      {/* File Rows */}
      {files.map((file) => (
        <div
          key={file.id}
          className={`border rounded-lg hover:bg-gray-50 transition-colors ${
            selectedFiles.includes(file.id) ? 'bg-blue-50 border-blue-200' : 'border-gray-200'
          }`}
        >
          {/* Desktop Layout */}
          <div className="hidden md:grid grid-cols-12 gap-4 p-3">
            {/* Selection */}
            <div className="col-span-1 flex items-center">
              <Checkbox
                checked={selectedFiles.includes(file.id)}
                onCheckedChange={(checked) => onFileSelect(file.id, checked as boolean)}
              />
            </div>

            {/* Preview Thumbnail */}
            <div className="col-span-1 flex items-center">
              <div className="w-10 h-10 bg-gray-100 rounded overflow-hidden cursor-pointer">
                <img
                  src={file.thumbnailUrl || file.dataUrl}
                  alt={file.name}
                  className="w-full h-full object-cover"
                  onClick={() => onPreview(file)}
                  loading="lazy"
                />
              </div>
            </div>

            {/* Name */}
            <div className="col-span-4 flex items-center">
              <div className="flex items-center space-x-2">
                <Image className="h-4 w-4 text-gray-400" />
                <span className="truncate font-medium" title={file.name}>
                  {file.name}
                </span>
                {file.name !== file.originalName && (
                  <Badge variant="outline" className="text-xs">
                    Renamed
                  </Badge>
                )}
              </div>
            </div>

            {/* Size */}
            <div className="col-span-2 flex items-center">
              <Badge variant="secondary">
                {formatBytes(file.size)}
              </Badge>
            </div>

            {/* Upload Date */}
            <div className="col-span-2 flex items-center text-sm text-gray-600">
              {new Date(file.uploadDate).toLocaleDateString()}
            </div>

            {/* Actions */}
            <div className="col-span-2 flex items-center space-x-1">
              <Button
                size="sm"
                variant="ghost"
                onClick={() => onPreview(file)}
                className="h-8 w-8 p-0"
                title="Preview"
              >
                <Eye className="h-4 w-4" />
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => onRename(file)}
                className="h-8 w-8 p-0"
                title="Rename"
              >
                <Edit className="h-4 w-4" />
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => onDownload(file.id)}
                className="h-8 w-8 p-0"
                title="Download"
              >
                <Download className="h-4 w-4" />
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => onDelete(file.id)}
                className="h-8 w-8 p-0 text-red-600 hover:text-red-700"
                title="Delete"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Mobile Layout */}
          <div className="md:hidden p-3">
            <div className="flex items-start space-x-3">
              {/* Selection Checkbox */}
              <Checkbox
                checked={selectedFiles.includes(file.id)}
                onCheckedChange={(checked) => onFileSelect(file.id, checked as boolean)}
                className="mt-1"
              />

              {/* Thumbnail */}
              <div 
                className="w-16 h-16 bg-gray-100 rounded overflow-hidden cursor-pointer flex-shrink-0"
                onClick={() => onPreview(file)}
              >
                <img
                  src={file.thumbnailUrl || file.dataUrl}
                  alt={file.name}
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
              </div>

              {/* File Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between">
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm truncate" title={file.name}>
                      {file.name}
                    </p>
                    <div className="flex items-center space-x-2 mt-1">
                      <Badge variant="secondary" className="text-xs">
                        {formatBytes(file.size)}
                      </Badge>
                      {file.name !== file.originalName && (
                        <Badge variant="outline" className="text-xs">
                          Renamed
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      {new Date(file.uploadDate).toLocaleDateString()}
                    </p>
                  </div>

                  {/* Mobile Actions Menu */}
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => onPreview(file)}>
                        <Eye className="h-4 w-4 mr-2" />
                        Preview
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => onRename(file)}>
                        <Edit className="h-4 w-4 mr-2" />
                        Rename
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => onDownload(file.id)}>
                        <Download className="h-4 w-4 mr-2" />
                        Download
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => onDelete(file.id)}
                        className="text-red-600"
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}