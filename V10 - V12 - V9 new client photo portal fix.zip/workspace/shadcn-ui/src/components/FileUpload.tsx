import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Upload, X, Image, File, AlertTriangle } from 'lucide-react';
import { FileStorageService, FileMetadata } from '@/lib/fileStorage';
import { toast } from 'sonner';

interface FileUploadProps {
  clientId: string;
  onUploadComplete: (files: FileMetadata[]) => void;
}

export default function FileUpload({ clientId, onUploadComplete }: FileUploadProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = Array.from(e.dataTransfer.files);
    handleFiles(files);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    handleFiles(files);
  };

  const handleFiles = async (files: File[]) => {
    if (files.length === 0) return;

    // Filter for image files
    const imageFiles = files.filter(file => file.type.startsWith('image/'));
    
    if (imageFiles.length === 0) {
      setError('Please select image files only (JPG, PNG, GIF, WebP)');
      return;
    }

    // Check file sizes - increased to 50MB per file to match storage limit
    const oversizedFiles = imageFiles.filter(file => file.size > 50 * 1024 * 1024); // 50MB limit
    if (oversizedFiles.length > 0) {
      setError(`Some files are too large. Maximum size is 50MB per file.`);
      return;
    }

    setUploading(true);
    setUploadProgress(0);
    setError(null);

    try {
      const uploadedFiles: FileMetadata[] = [];
      
      for (let i = 0; i < imageFiles.length; i++) {
        const file = imageFiles[i];
        try {
          const fileMetadata = await FileStorageService.uploadFile(file, clientId);
          uploadedFiles.push(fileMetadata);
          setUploadProgress(((i + 1) / imageFiles.length) * 100);
        } catch (fileError) {
          console.error(`Error uploading ${file.name}:`, fileError);
          if (fileError instanceof Error) {
            if (fileError.message.includes('quota')) {
              setError('Storage quota exceeded. Please delete some files and try again.');
              break;
            } else {
              toast.error(`Failed to upload ${file.name}: ${fileError.message}`);
            }
          }
        }
      }

      if (uploadedFiles.length > 0) {
        onUploadComplete(uploadedFiles);
        toast.success(`Successfully uploaded ${uploadedFiles.length} file(s)`);
      }
      
      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (error) {
      console.error('Upload error:', error);
      if (error instanceof Error && error.message.includes('quota')) {
        setError('Storage quota exceeded. Please delete some files and try again.');
      } else {
        setError('Failed to upload files. Please try again.');
      }
    } finally {
      setUploading(false);
      setUploadProgress(0);
    }
  };

  const openFileDialog = () => {
    fileInputRef.current?.click();
  };

  const storageInfo = FileStorageService.getStorageInfo();
  const storagePercentage = (storageInfo.estimated / storageInfo.maxStorage) * 100;

  return (
    <Card className="mb-6">
      <CardContent className="p-6">
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {/* Storage Info */}
        <div className="mb-4 p-3 bg-blue-50 rounded-lg">
          <div className="flex items-center justify-between text-sm">
            <span className="text-blue-700">Storage Used:</span>
            <span className="font-medium text-blue-800">
              {storageInfo.estimated}MB / {storageInfo.maxStorage}MB ({storageInfo.fileCount} files)
            </span>
          </div>
          <Progress 
            value={storagePercentage} 
            className="mt-2 h-2"
          />
          {storagePercentage > 80 && (
            <p className="text-xs text-orange-600 mt-1">
              Storage is {Math.round(storagePercentage)}% full
            </p>
          )}
        </div>

        <div
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
            isDragging
              ? 'border-blue-500 bg-blue-50'
              : 'border-gray-300 hover:border-gray-400'
          }`}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          {uploading ? (
            <div className="space-y-4">
              <div className="animate-spin mx-auto">
                <Upload className="h-8 w-8 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600 mb-2">Compressing and uploading files...</p>
                <Progress value={uploadProgress} className="w-full max-w-xs mx-auto" />
                <p className="text-xs text-gray-500 mt-1">{Math.round(uploadProgress)}%</p>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex justify-center">
                <div className="p-3 bg-blue-100 rounded-full">
                  <Image className="h-8 w-8 text-blue-600" />
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-2">Upload Photos</h3>
                <p className="text-gray-600 mb-4">
                  Drag and drop your photos here, or click to browse
                </p>
                <Button 
                  onClick={openFileDialog} 
                  className="mb-2" 
                  disabled={storagePercentage >= 100}
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Choose Files
                </Button>
                <p className="text-xs text-gray-500">
                  Supports: JPG, PNG, GIF, WebP • Max 50MB per file • 50MB total storage
                </p>
                {storagePercentage >= 100 && (
                  <p className="text-xs text-red-500 mt-2">
                    Storage full. Delete files to upload more.
                  </p>
                )}
              </div>
            </div>
          )}
        </div>

        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept="image/*"
          onChange={handleFileSelect}
          className="hidden"
        />
      </CardContent>
    </Card>
  );
}