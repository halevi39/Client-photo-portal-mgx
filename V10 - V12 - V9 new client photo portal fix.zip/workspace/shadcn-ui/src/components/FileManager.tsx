import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FileStorageService, FileMetadata } from '@/lib/fileStorage';
import { User } from '@/lib/auth';
import FileUpload from './FileUpload';
import PhotoGrid from './PhotoGrid';
import PhotoList from './PhotoList';
import PhotoPreview from './PhotoPreview';
import RenameModal from './RenameModal';
import BulkRenameModal from './BulkRenameModal';
import ContactSheet from './ContactSheet';
import CommentBox from './CommentBox';
import { 
  Download, 
  Trash2, 
  Grid3X3, 
  List, 
  Search, 
  Filter,
  CheckSquare,
  Square,
  Edit3,
  FileText,
  LogOut,
  User as UserIcon,
  Layout,
  MessageCircle
} from 'lucide-react';
import { toast } from 'sonner';
import { formatBytes } from '@/lib/utils';

interface FileManagerProps {
  user: User;
  onLogout: () => void;
}

export default function FileManager({ user, onLogout }: FileManagerProps) {
  const [files, setFiles] = useState<FileMetadata[]>([]);
  const [filteredFiles, setFilteredFiles] = useState<FileMetadata[]>([]);
  const [selectedFiles, setSelectedFiles] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<'name' | 'date' | 'size'>('date');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [previewFile, setPreviewFile] = useState<FileMetadata | null>(null);
  const [renameFile, setRenameFile] = useState<FileMetadata | null>(null);
  const [showBulkRename, setShowBulkRename] = useState(false);
  const [showContactSheet, setShowContactSheet] = useState(false);

  useEffect(() => {
    loadFiles();
  }, [user]);

  useEffect(() => {
    filterAndSortFiles();
  }, [files, searchTerm, sortBy]);

  const loadFiles = () => {
    const userFiles = user.role === 'admin' 
      ? FileStorageService.getAllFiles()
      : FileStorageService.getClientFiles(user.id);
    setFiles(userFiles);
  };

  const filterAndSortFiles = () => {
    const filtered = files.filter(file =>
      file.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'name':
          return a.name.localeCompare(b.name);
        case 'size':
          return b.size - a.size;
        case 'date':
        default:
          return new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime();
      }
    });

    setFilteredFiles(filtered);
  };

  const handleUploadComplete = (newFiles: FileMetadata[]) => {
    loadFiles();
    toast.success(`Uploaded ${newFiles.length} file(s) successfully`);
  };

  const handleFileSelect = (fileId: string, selected: boolean) => {
    setSelectedFiles(prev =>
      selected
        ? [...prev, fileId]
        : prev.filter(id => id !== fileId)
    );
  };

  const handleSelectAll = () => {
    if (selectedFiles.length === filteredFiles.length) {
      setSelectedFiles([]);
    } else {
      setSelectedFiles(filteredFiles.map(f => f.id));
    }
  };

  const handleRename = (fileId: string, newName: string) => {
    try {
      if (FileStorageService.updateFileName(fileId, newName)) {
        loadFiles();
        toast.success('File renamed successfully');
        setRenameFile(null); // Close the modal after successful rename
      } else {
        toast.error('Failed to rename file');
      }
    } catch (error) {
      console.error('Error renaming file:', error);
      toast.error('Failed to rename file');
    }
  };

  const handleBulkRename = (operation: {
    type: 'text-number' | 'number-only';
    prefix?: string;
    startNumber: number;
    padding: number;
  }) => {
    const selectedFileObjects = files.filter(f => selectedFiles.includes(f.id));
    
    selectedFileObjects.forEach((file, index) => {
      const extension = file.name.includes('.') ? '.' + file.name.split('.').pop() : '';
      const number = (operation.startNumber + index).toString().padStart(operation.padding, '0');
      
      let newName: string;
      if (operation.type === 'text-number' && operation.prefix) {
        newName = `${operation.prefix}${number}${extension}`;
      } else {
        newName = `${number}${extension}`;
      }
      
      FileStorageService.updateFileName(file.id, newName);
    });

    loadFiles();
    setSelectedFiles([]);
    toast.success(`Renamed ${selectedFileObjects.length} files`);
  };

  const handleDownload = (fileId: string) => {
    FileStorageService.downloadFile(fileId);
  };

  const handleBulkDownload = () => {
    selectedFiles.forEach(fileId => {
      FileStorageService.downloadFile(fileId);
    });
    toast.success(`Downloaded ${selectedFiles.length} files`);
  };

  const handleDelete = (fileId: string) => {
    if (FileStorageService.deleteFile(fileId)) {
      loadFiles();
      setSelectedFiles(prev => prev.filter(id => id !== fileId));
      toast.success('File deleted successfully');
    } else {
      toast.error('Failed to delete file');
    }
  };

  const handleBulkDelete = () => {
    selectedFiles.forEach(fileId => {
      FileStorageService.deleteFile(fileId);
    });
    loadFiles();
    setSelectedFiles([]);
    toast.success(`Deleted ${selectedFiles.length} files`);
  };

  const handleExportList = () => {
    FileStorageService.exportFileList(user.id);
    toast.success('File list exported');
  };

  const handleContactSheet = () => {
    setShowContactSheet(true);
  };

  const getTotalSize = () => {
    return filteredFiles.reduce((total, file) => total + file.size, 0);
  };

  const allFilesSelected = selectedFiles.length === filteredFiles.length && filteredFiles.length > 0;

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex flex-col sm:flex-row sm:items-center space-y-2 sm:space-y-0 sm:space-x-4">
          <h1 className="text-xl md:text-2xl font-bold">
            {user.role === 'admin' ? 'All Files' : 'My Photos'}
          </h1>
          <Badge variant="secondary" className="w-fit">
            {filteredFiles.length} files • {formatBytes(getTotalSize())}
          </Badge>
        </div>
        
        <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-2 sm:space-y-0 sm:space-x-4 w-full sm:w-auto">
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <UserIcon className="h-4 w-4" />
            <span className="truncate">{user.name}</span>
          </div>
          <Button variant="outline" onClick={onLogout} className="w-full sm:w-auto">
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </div>

      {/* Upload Section - Only for clients */}
      {user.role === 'client' && (
        <FileUpload clientId={user.id} onUploadComplete={handleUploadComplete} />
      )}

      {/* Comment Box - Only for clients */}
      {user.role === 'client' && (
        <CommentBox user={user} />
      )}

      {/* Controls */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col gap-4">
            {/* Search and Filter */}
            <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
              <div className="relative flex-1 w-full sm:max-w-sm">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search files..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              
              <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
                <Select value={sortBy} onValueChange={(value) => setSortBy(value as 'name' | 'date' | 'size')}>
                  <SelectTrigger className="w-full sm:w-40">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="date">Sort by Date</SelectItem>
                    <SelectItem value="name">Sort by Name</SelectItem>
                    <SelectItem value="size">Sort by Size</SelectItem>
                  </SelectContent>
                </Select>

                {/* View Mode */}
                <div className="flex items-center space-x-2">
                  <Button
                    variant={viewMode === 'grid' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setViewMode('grid')}
                  >
                    <Grid3X3 className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={viewMode === 'list' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setViewMode('list')}
                  >
                    <List className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Bulk Actions */}
            {filteredFiles.length > 0 && (
              <div className="flex flex-col gap-4 pt-4 border-t">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="flex flex-col sm:flex-row sm:items-center space-y-2 sm:space-y-0 sm:space-x-4">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleSelectAll}
                      className="w-full sm:w-auto"
                    >
                      {selectedFiles.length === filteredFiles.length ? (
                        <CheckSquare className="h-4 w-4 mr-2" />
                      ) : (
                        <Square className="h-4 w-4 mr-2" />
                      )}
                      {selectedFiles.length === filteredFiles.length ? 'Deselect All' : 'Select All'}
                    </Button>
                    
                    {selectedFiles.length > 0 && (
                      <Badge variant="secondary">
                        {selectedFiles.length} selected
                      </Badge>
                    )}
                  </div>

                  {/* Contact Sheet Button - Show when all files are selected */}
                  {allFilesSelected && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleContactSheet}
                      className="w-full sm:w-auto"
                    >
                      <Layout className="h-4 w-4 mr-2" />
                      Contact Sheet
                    </Button>
                  )}
                </div>

                {/* Action Buttons - Two rows for mobile */}
                {selectedFiles.length > 0 && (
                  <div className="grid grid-cols-2 md:flex md:flex-wrap gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowBulkRename(true)}
                      className="flex-1 md:flex-none"
                    >
                      <Edit3 className="h-4 w-4 mr-2" />
                      <span className="hidden sm:inline">Batch Rename</span>
                      <span className="sm:hidden">Rename</span>
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleBulkDownload}
                      className="flex-1 md:flex-none"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      <span className="hidden sm:inline">Download All</span>
                      <span className="sm:hidden">Download</span>
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleExportList}
                      className="flex-1 md:flex-none"
                    >
                      <FileText className="h-4 w-4 mr-2" />
                      <span className="hidden sm:inline">Export List</span>
                      <span className="sm:hidden">Export</span>
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={handleBulkDelete}
                      className="flex-1 md:flex-none"
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      <span className="hidden sm:inline">Delete All</span>
                      <span className="sm:hidden">Delete</span>
                    </Button>
                  </div>
                )}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* File Display */}
      <div>
        {viewMode === 'grid' ? (
          <PhotoGrid
            files={filteredFiles}
            selectedFiles={selectedFiles}
            onFileSelect={handleFileSelect}
            onPreview={setPreviewFile}
            onRename={setRenameFile}
            onDownload={handleDownload}
            onDelete={handleDelete}
          />
        ) : (
          <PhotoList
            files={filteredFiles}
            selectedFiles={selectedFiles}
            onFileSelect={handleFileSelect}
            onPreview={setPreviewFile}
            onRename={setRenameFile}
            onDownload={handleDownload}
            onDelete={handleDelete}
          />
        )}
      </div>

      {/* Modals */}
      {previewFile && (
        <PhotoPreview
          file={previewFile}
          onClose={() => setPreviewFile(null)}
          onDownload={handleDownload}
          onDelete={handleDelete}
        />
      )}

      {renameFile && (
        <RenameModal
          file={renameFile}
          onClose={() => setRenameFile(null)}
          onRename={handleRename}
        />
      )}

      <BulkRenameModal
        isOpen={showBulkRename}
        onClose={() => setShowBulkRename(false)}
        onRename={handleBulkRename}
        selectedFiles={files.filter(f => selectedFiles.includes(f.id))}
      />

      {showContactSheet && (
        <ContactSheet
          files={files.filter(f => selectedFiles.includes(f.id))}
          onClose={() => setShowContactSheet(false)}
          onDownload={handleBulkDownload}
        />
      )}
    </div>
  );
}