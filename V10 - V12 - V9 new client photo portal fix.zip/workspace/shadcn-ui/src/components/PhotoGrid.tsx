import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { FileMetadata } from '@/lib/fileStorage';
import { Eye, Download, Edit, Trash2 } from 'lucide-react';
import { formatBytes } from '@/lib/utils';

interface PhotoGridProps {
  files: FileMetadata[];
  selectedFiles: string[];
  onFileSelect: (fileId: string, selected: boolean) => void;
  onPreview: (file: FileMetadata) => void;
  onRename: (file: FileMetadata) => void;
  onDownload: (fileId: string) => void;
  onDelete: (fileId: string) => void;
}

export default function PhotoGrid({
  files,
  selectedFiles,
  onFileSelect,
  onPreview,
  onRename,
  onDownload,
  onDelete
}: PhotoGridProps) {
  const [hoveredFile, setHoveredFile] = useState<string | null>(null);

  if (files.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500">
        <div className="text-6xl mb-4">📷</div>
        <h3 className="text-lg font-semibold mb-2">No photos uploaded yet</h3>
        <p>Upload your first photos to get started</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 xs:grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-8 gap-3 md:gap-4">
      {files.map((file) => (
        <Card
          key={file.id}
          className={`overflow-hidden transition-all duration-200 hover:shadow-lg ${
            selectedFiles.includes(file.id) ? 'ring-2 ring-blue-500' : ''
          }`}
          onMouseEnter={() => setHoveredFile(file.id)}
          onMouseLeave={() => setHoveredFile(null)}
        >
          <CardContent className="p-0 relative">
            {/* Selection Checkbox */}
            <div className="absolute top-2 left-2 z-20">
              <Checkbox
                checked={selectedFiles.includes(file.id)}
                onCheckedChange={(checked) => onFileSelect(file.id, checked as boolean)}
                className="bg-white/90 backdrop-blur-sm border-2"
              />
            </div>

            {/* Image Thumbnail */}
            <div 
              className="aspect-square bg-gray-100 cursor-pointer overflow-hidden relative"
              onClick={() => onPreview(file)}
            >
              <img
                src={file.thumbnailUrl || file.dataUrl}
                alt={file.name}
                className="w-full h-full object-cover transition-transform duration-200 hover:scale-105"
                loading="lazy"
              />

              {/* Large Action Icons Overlay - Show on Hover */}
              {hoveredFile === file.id && (
                <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-10 transition-opacity duration-200">
                  <div className="flex items-center space-x-3">
                    {/* Preview */}
                    <Button
                      variant="ghost"
                      size="lg"
                      className="h-12 w-12 p-0 bg-white/20 hover:bg-white/30 text-white border border-white/30"
                      onClick={(e) => {
                        e.stopPropagation();
                        onPreview(file);
                      }}
                      title="Preview"
                    >
                      <Eye className="h-6 w-6" />
                    </Button>

                    {/* Rename */}
                    <Button
                      variant="ghost"
                      size="lg"
                      className="h-12 w-12 p-0 bg-white/20 hover:bg-white/30 text-white border border-white/30"
                      onClick={(e) => {
                        e.stopPropagation();
                        onRename(file);
                      }}
                      title="Rename"
                    >
                      <Edit className="h-6 w-6" />
                    </Button>

                    {/* Download */}
                    <Button
                      variant="ghost"
                      size="lg"
                      className="h-12 w-12 p-0 bg-white/20 hover:bg-white/30 text-white border border-white/30"
                      onClick={(e) => {
                        e.stopPropagation();
                        onDownload(file.id);
                      }}
                      title="Download"
                    >
                      <Download className="h-6 w-6" />
                    </Button>

                    {/* Delete */}
                    <Button
                      variant="ghost"
                      size="lg"
                      className="h-12 w-12 p-0 bg-red-500/20 hover:bg-red-500/30 text-white border border-red-300/30"
                      onClick={(e) => {
                        e.stopPropagation();
                        onDelete(file.id);
                      }}
                      title="Delete"
                    >
                      <Trash2 className="h-6 w-6" />
                    </Button>
                  </div>
                </div>
              )}
            </div>

            {/* File Info */}
            <div className="p-2">
              <p className="text-xs font-medium truncate" title={file.name}>
                {file.name}
              </p>
              <div className="flex items-center justify-between mt-1">
                <Badge variant="secondary" className="text-xs">
                  {formatBytes(file.size)}
                </Badge>
                <span className="text-xs text-gray-500">
                  {new Date(file.uploadDate).toLocaleDateString()}
                </span>
              </div>
              
              {/* Mobile Action Buttons */}
              <div className="md:hidden mt-2 flex items-center justify-between">
                <div className="flex space-x-1">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => onPreview(file)}
                    className="h-6 w-6 p-0"
                    title="Preview"
                  >
                    <Eye className="h-3 w-3" />
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => onRename(file)}
                    className="h-6 w-6 p-0"
                    title="Rename"
                  >
                    <Edit className="h-3 w-3" />
                  </Button>
                </div>
                <div className="flex space-x-1">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => onDownload(file.id)}
                    className="h-6 w-6 p-0"
                    title="Download"
                  >
                    <Download className="h-3 w-3" />
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => onDelete(file.id)}
                    className="h-6 w-6 p-0 text-red-600"
                    title="Delete"
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}