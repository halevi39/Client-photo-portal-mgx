import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { FileMetadata } from '@/lib/fileStorage';
import { Download, Printer, X, Settings } from 'lucide-react';
import { formatBytes } from '@/lib/utils';

interface ContactSheetProps {
  files: FileMetadata[];
  onClose: () => void;
  onDownload: () => void;
}

export default function ContactSheet({ files, onClose, onDownload }: ContactSheetProps) {
  const [columns, setColumns] = useState(3);
  const [showSettings, setShowSettings] = useState(false);

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    // Group files into rows
    const rows = [];
    for (let i = 0; i < files.length; i += columns) {
      rows.push(files.slice(i, i + columns));
    }

    let printContent = `
      <html>
        <head>
          <title>Contact Sheet</title>
          <style>
            @page { 
              size: A4; 
              margin: 15mm; 
            }
            * {
              box-sizing: border-box;
            }
            body { 
              font-family: Arial, sans-serif; 
              margin: 0; 
              padding: 0;
            }
            .header {
              text-align: center;
              margin-bottom: 20px;
              border-bottom: 2px solid #333;
              padding-bottom: 10px;
            }
            table {
              width: 100%;
              border-collapse: separate;
              border-spacing: 8px;
            }
            td {
              width: ${100/columns}%;
              vertical-align: top;
              border: 1px solid #ddd;
              padding: 8px;
              background: white;
            }
            td img {
              width: 100%;
              height: auto;
              display: block;
            }
            .photo-info {
              font-size: 8px;
              text-align: center;
              margin-top: 5px;
              word-wrap: break-word;
            }
          </style>
        </head>
        <body>
          <div class="header">
            <h2>Contact Sheet</h2>
            <p>Total Photos: ${files.length} | ${columns} columns</p>
          </div>
          <table>
    `;

    rows.forEach(row => {
      printContent += '<tr>';
      for (let i = 0; i < columns; i++) {
        const file = row[i];
        printContent += '<td>';
        if (file) {
          printContent += `
            <img src="${file.thumbnailUrl || file.dataUrl}" alt="${file.name}" />
            <div class="photo-info">
              <div><strong>${file.name}</strong></div>
              <div>${formatBytes(file.size)}</div>
            </div>
          `;
        }
        printContent += '</td>';
      }
      printContent += '</tr>';
    });

    printContent += '</table></body></html>';
    
    printWindow.document.write(printContent);
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
  };

  const handleDownloadContactSheet = () => {
    handlePrint();
    onDownload();
  };

  // Group files into rows
  const rows = [];
  for (let i = 0; i < files.length; i += columns) {
    rows.push(files.slice(i, i + columns));
  }

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[95vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>Contact Sheet Preview</span>
            <div className="flex items-center space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowSettings(!showSettings)}
              >
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Button>
              <Button variant="ghost" size="sm" onClick={onClose}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </DialogTitle>
        </DialogHeader>

        <div className="flex flex-col h-full space-y-4">
          {/* Settings Panel */}
          {showSettings && (
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div>
                      <Label htmlFor="columns">Columns</Label>
                      <Input
                        id="columns"
                        type="number"
                        min="1"
                        max="4"
                        value={columns}
                        onChange={(e) => setColumns(Math.max(1, Math.min(4, parseInt(e.target.value) || 1)))}
                        className="w-20"
                      />
                    </div>
                    <div className="text-sm text-gray-600">
                      Total Photos: {files.length}
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Button onClick={handlePrint} size="sm">
                      <Printer className="h-4 w-4 mr-2" />
                      Print
                    </Button>
                    <Button onClick={handleDownloadContactSheet} size="sm">
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Contact Sheet Preview - HTML TABLE LAYOUT */}
          <div className="flex-1 overflow-auto">
            <div className="bg-white border rounded-lg p-6 shadow-sm">
              <div className="text-center mb-6 border-b pb-4">
                <h3 className="text-lg font-semibold">Contact Sheet</h3>
                <p className="text-sm text-gray-600">
                  {files.length} photos | {columns} columns layout
                </p>
              </div>
              
              {/* Traditional HTML table - each row adjusts to tallest image */}
              <table style={{ width: '100%', borderCollapse: 'separate', borderSpacing: '8px' }}>
                <tbody>
                  {rows.map((row, rowIndex) => (
                    <tr key={rowIndex}>
                      {Array.from({ length: columns }, (_, colIndex) => {
                        const file = row[colIndex];
                        return (
                          <td 
                            key={colIndex}
                            style={{
                              width: `${100/columns}%`,
                              verticalAlign: 'top',
                              border: '1px solid #e5e7eb',
                              padding: '8px',
                              backgroundColor: 'white',
                              borderRadius: '4px'
                            }}
                          >
                            {file ? (
                              <>
                                <img
                                  src={file.thumbnailUrl || file.dataUrl}
                                  alt={file.name}
                                  style={{
                                    width: '100%',
                                    height: 'auto',
                                    display: 'block'
                                  }}
                                  loading="lazy"
                                />
                                <div style={{ fontSize: '12px', textAlign: 'center', marginTop: '8px' }}>
                                  <div style={{ fontWeight: '500', marginBottom: '2px' }} title={file.name}>
                                    {file.name.length > 20 ? file.name.substring(0, 20) + '...' : file.name}
                                  </div>
                                  <div style={{ color: '#6b7280', fontSize: '10px' }}>
                                    {formatBytes(file.size)}
                                  </div>
                                </div>
                              </>
                            ) : null}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}