import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { FileStorageService, FileMetadata } from '@/lib/fileStorage';
import { User } from '@/lib/auth';
import PhotoGrid from './PhotoGrid';
import PhotoList from './PhotoList';
import PhotoPreview from './PhotoPreview';
import RenameModal from './RenameModal';
import BulkRenameModal from './BulkRenameModal';
import { 
  Download, 
  Trash2, 
  Grid3X3, 
  List, 
  Search, 
  Filter,
  CheckSquare,
  Square,
  Edit3,
  FileText,
  ArrowLeft
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { formatBytes } from '@/lib/utils';

interface ClientFileViewerProps {
  client: User;
  onClose: () => void;
}

export default function ClientFileViewer({ client, onClose }: ClientFileViewerProps) {
  const [files, setFiles] = useState<FileMetadata[]>([]);
  const [filteredFiles, setFilteredFiles] = useState<FileMetadata[]>([]);
  const [selectedFiles, setSelectedFiles] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<'name' | 'date' | 'size'>('date');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [previewFile, setPreviewFile] = useState<FileMetadata | null>(null);
  const [renameFile, setRenameFile] = useState<FileMetadata | null>(null);
  const [showBulkRename, setShowBulkRename] = useState(false);

  useEffect(() => {
    loadFiles();
  }, [client]);

  useEffect(() => {
    filterAndSortFiles();
  }, [files, searchTerm, sortBy]);

  const loadFiles = () => {
    const clientFiles = FileStorageService.getClientFiles(client.id);
    setFiles(clientFiles);
  };

  const filterAndSortFiles = () => {
    const filtered = files.filter(file =>
      file.name.toLowerCase().includes(searchTerm.toLowerCase())
    );

    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'name':
          return a.name.localeCompare(b.name);
        case 'size':
          return b.size - a.size;
        case 'date':
        default:
          return new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime();
      }
    });

    setFilteredFiles(filtered);
  };

  const handleFileSelect = (fileId: string, selected: boolean) => {
    setSelectedFiles(prev =>
      selected
        ? [...prev, fileId]
        : prev.filter(id => id !== fileId)
    );
  };

  const handleSelectAll = () => {
    if (selectedFiles.length === filteredFiles.length) {
      setSelectedFiles([]);
    } else {
      setSelectedFiles(filteredFiles.map(f => f.id));
    }
  };

  const handleRename = (fileId: string, newName: string) => {
    if (FileStorageService.updateFileName(fileId, newName)) {
      loadFiles();
      toast.success('File renamed successfully');
    } else {
      toast.error('Failed to rename file');
    }
  };

  const handleBulkRename = (operation: {
    type: 'text-number' | 'number-only';
    prefix?: string;
    startNumber: number;
    padding: number;
  }) => {
    const selectedFileObjects = files.filter(f => selectedFiles.includes(f.id));
    
    selectedFileObjects.forEach((file, index) => {
      const extension = file.name.includes('.') ? '.' + file.name.split('.').pop() : '';
      const number = (operation.startNumber + index).toString().padStart(operation.padding, '0');
      
      let newName: string;
      if (operation.type === 'text-number' && operation.prefix) {
        newName = `${operation.prefix}${number}${extension}`;
      } else {
        newName = `${number}${extension}`;
      }
      
      FileStorageService.updateFileName(file.id, newName);
    });

    loadFiles();
    setSelectedFiles([]);
    toast.success(`Renamed ${selectedFileObjects.length} files`);
  };

  const handleDownload = (fileId: string) => {
    FileStorageService.downloadFile(fileId);
  };

  const handleBulkDownload = () => {
    selectedFiles.forEach(fileId => {
      FileStorageService.downloadFile(fileId);
    });
    toast.success(`Downloaded ${selectedFiles.length} files`);
  };

  const handleDelete = (fileId: string) => {
    if (FileStorageService.deleteFile(fileId)) {
      loadFiles();
      setSelectedFiles(prev => prev.filter(id => id !== fileId));
      toast.success('File deleted successfully');
    } else {
      toast.error('Failed to delete file');
    }
  };

  const handleBulkDelete = () => {
    selectedFiles.forEach(fileId => {
      FileStorageService.deleteFile(fileId);
    });
    loadFiles();
    setSelectedFiles([]);
    toast.success(`Deleted ${selectedFiles.length} files`);
  };

  const handleExportList = () => {
    FileStorageService.exportFileList(client.id);
    toast.success('File list exported');
  };

  const getTotalSize = () => {
    return filteredFiles.reduce((total, file) => total + file.size, 0);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-7xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" onClick={onClose}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
              <div>
                <DialogTitle className="text-xl">
                  {client.name}'s Files
                </DialogTitle>
                <p className="text-sm text-gray-600">@{client.username}</p>
              </div>
              <Badge variant="secondary">
                {filteredFiles.length} files • {formatBytes(getTotalSize())}
              </Badge>
            </div>
          </div>
        </DialogHeader>

        <div className="space-y-4 overflow-y-auto">
          {/* Controls */}
          <Card>
            <CardContent className="p-4">
              <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
                {/* Search and Filter */}
                <div className="flex items-center space-x-4 flex-1">
                  <div className="relative flex-1 max-w-sm">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      placeholder="Search files..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  
                  <Select value={sortBy} onValueChange={(value) => setSortBy(value as 'name' | 'date' | 'size')}>
                    <SelectTrigger className="w-40">
                      <Filter className="h-4 w-4 mr-2" />
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="date">Sort by Date</SelectItem>
                      <SelectItem value="name">Sort by Name</SelectItem>
                      <SelectItem value="size">Sort by Size</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* View Mode */}
                <div className="flex items-center space-x-2">
                  <Button
                    variant={viewMode === 'grid' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setViewMode('grid')}
                  >
                    <Grid3X3 className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={viewMode === 'list' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setViewMode('list')}
                  >
                    <List className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Bulk Actions */}
              {filteredFiles.length > 0 && (
                <div className="flex items-center justify-between mt-4 pt-4 border-t">
                  <div className="flex items-center space-x-4">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleSelectAll}
                    >
                      {selectedFiles.length === filteredFiles.length ? (
                        <CheckSquare className="h-4 w-4 mr-2" />
                      ) : (
                        <Square className="h-4 w-4 mr-2" />
                      )}
                      {selectedFiles.length === filteredFiles.length ? 'Deselect All' : 'Select All'}
                    </Button>
                    
                    {selectedFiles.length > 0 && (
                      <Badge variant="secondary">
                        {selectedFiles.length} selected
                      </Badge>
                    )}
                  </div>

                  {selectedFiles.length > 0 && (
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setShowBulkRename(true)}
                      >
                        <Edit3 className="h-4 w-4 mr-2" />
                        Batch Rename
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={handleBulkDownload}
                      >
                        <Download className="h-4 w-4 mr-2" />
                        Download All
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={handleExportList}
                      >
                        <FileText className="h-4 w-4 mr-2" />
                        Export List
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={handleBulkDelete}
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete All
                      </Button>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {/* File Display */}
          <div className="max-h-96 overflow-y-auto">
            {viewMode === 'grid' ? (
              <PhotoGrid
                files={filteredFiles}
                selectedFiles={selectedFiles}
                onFileSelect={handleFileSelect}
                onPreview={setPreviewFile}
                onRename={setRenameFile}
                onDownload={handleDownload}
                onDelete={handleDelete}
              />
            ) : (
              <PhotoList
                files={filteredFiles}
                selectedFiles={selectedFiles}
                onFileSelect={handleFileSelect}
                onPreview={setPreviewFile}
                onRename={setRenameFile}
                onDownload={handleDownload}
                onDelete={handleDelete}
              />
            )}
          </div>
        </div>

        {/* Modals */}
        {previewFile && (
          <PhotoPreview
            file={previewFile}
            onClose={() => setPreviewFile(null)}
            onDownload={handleDownload}
            onDelete={handleDelete}
          />
        )}

        {renameFile && (
          <RenameModal
            file={renameFile}
            onClose={() => setRenameFile(null)}
            onRename={handleRename}
          />
        )}

        <BulkRenameModal
          isOpen={showBulkRename}
          onClose={() => setShowBulkRename(false)}
          onRename={handleBulkRename}
          selectedFiles={files.filter(f => selectedFiles.includes(f.id))}
        />
      </DialogContent>
    </Dialog>
  );
}