import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { FileMetadata } from '@/lib/fileStorage';
import { Download, Edit, X, Calendar, HardDrive, Trash2 } from 'lucide-react';
import { formatBytes } from '@/lib/utils';

interface PhotoPreviewProps {
  file: FileMetadata;
  onClose: () => void;
  onDownload: (fileId: string) => void;
  onDelete: (fileId: string) => void;
}

export default function PhotoPreview({
  file,
  onClose,
  onDownload,
  onDelete
}: PhotoPreviewProps) {
  if (!file) return null;

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span className="truncate mr-4">{file.name}</span>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>

        <div className="flex flex-col lg:flex-row gap-6">
          {/* Image Preview */}
          <div className="flex-1 flex items-center justify-center bg-gray-50 rounded-lg overflow-hidden">
            <img
              src={file.dataUrl}
              alt={file.name}
              className="max-w-full max-h-[60vh] object-contain"
            />
          </div>

          {/* File Details */}
          <div className="lg:w-80 space-y-4">
            <div className="space-y-3">
              <div>
                <h4 className="font-semibold text-sm text-gray-700 mb-1">File Name</h4>
                <p className="text-sm break-all">{file.name}</p>
                {file.name !== file.originalName && (
                  <p className="text-xs text-gray-500 mt-1">
                    Original: {file.originalName}
                  </p>
                )}
              </div>

              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-1">
                  <HardDrive className="h-4 w-4 text-gray-400" />
                  <Badge variant="secondary">
                    {formatBytes(file.size)}
                  </Badge>
                </div>
                <div className="flex items-center space-x-1">
                  <Calendar className="h-4 w-4 text-gray-400" />
                  <span className="text-sm text-gray-600">
                    {new Date(file.uploadDate).toLocaleDateString()}
                  </span>
                </div>
              </div>

              <div>
                <h4 className="font-semibold text-sm text-gray-700 mb-1">File Type</h4>
                <Badge variant="outline">{file.type}</Badge>
              </div>

              {file.folder && (
                <div>
                  <h4 className="font-semibold text-sm text-gray-700 mb-1">Folder</h4>
                  <p className="text-sm text-gray-600">{file.folder}</p>
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="space-y-2 pt-4 border-t">
              <Button
                onClick={() => onDownload(file.id)}
                className="w-full justify-start"
              >
                <Download className="h-4 w-4 mr-2" />
                Download File
              </Button>
              
              <Button
                onClick={() => onDelete(file.id)}
                variant="destructive"
                className="w-full justify-start"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Delete File
              </Button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}