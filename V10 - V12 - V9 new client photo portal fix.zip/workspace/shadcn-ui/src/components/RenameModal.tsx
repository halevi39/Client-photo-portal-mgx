import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { FileMetadata } from '@/lib/fileStorage';

interface RenameModalProps {
  file: FileMetadata | null;
  onRename: (fileId: string, newName: string) => void;
  onClose: () => void;
}

export default function RenameModal({ file, onRename, onClose }: RenameModalProps) {
  const [newName, setNewName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (file) {
      // Remove the extension for editing, we'll add it back automatically
      const nameWithoutExtension = file.name.replace(/\.[^/.]+$/, '');
      setNewName(nameWithoutExtension);
    }
  }, [file]);

  const getFileExtension = (filename: string): string => {
    const match = filename.match(/\.[^/.]+$/);
    return match ? match[0] : '.jpg'; // Default to .jpg if no extension found
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file || !newName.trim()) return;

    setIsSubmitting(true);
    
    try {
      // Get the original file extension
      const originalExtension = getFileExtension(file.name);
      
      // Clean the new name and ensure it has the correct extension
      let finalName = newName.trim();
      
      // Remove any extension the user might have typed
      finalName = finalName.replace(/\.[^/.]+$/, '');
      
      // Add the original extension back
      finalName = finalName + originalExtension;
      
      // Validate the name
      if (finalName === originalExtension) {
        alert('Please enter a valid filename');
        return;
      }
      
      // Pass both fileId and newName to the onRename function
      await onRename(file.id, finalName);
      onClose();
    } catch (error) {
      console.error('Error renaming file:', error);
      alert('Failed to rename file. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape') {
      onClose();
    }
  };

  if (!file) return null;

  const originalExtension = getFileExtension(file.name);

  return (
    <Dialog open={!!file} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Rename Photo</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="filename">New filename</Label>
            <div className="flex items-center space-x-2">
              <Input
                id="filename"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Enter new filename"
                className="flex-1"
                autoFocus
                disabled={isSubmitting}
              />
              <span className="text-sm text-gray-500 font-mono bg-gray-100 px-2 py-1 rounded">
                {originalExtension}
              </span>
            </div>
            <p className="text-xs text-gray-500">
              The file extension ({originalExtension}) will be automatically added
            </p>
          </div>

          <div className="bg-gray-50 p-3 rounded-lg">
            <p className="text-sm text-gray-600 mb-1">Current name:</p>
            <p className="font-medium text-sm">{file.name}</p>
            
            {newName.trim() && (
              <>
                <p className="text-sm text-gray-600 mb-1 mt-2">New name will be:</p>
                <p className="font-medium text-sm text-blue-600">
                  {newName.trim().replace(/\.[^/.]+$/, '') + originalExtension}
                </p>
              </>
            )}
          </div>

          <DialogFooter className="flex space-x-2">
            <Button 
              type="button" 
              variant="outline" 
              onClick={onClose}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={!newName.trim() || isSubmitting}
            >
              {isSubmitting ? 'Renaming...' : 'Rename'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}