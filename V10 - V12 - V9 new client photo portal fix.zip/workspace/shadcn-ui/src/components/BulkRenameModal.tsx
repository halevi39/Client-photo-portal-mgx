import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { FileMetadata } from '@/lib/fileStorage';

interface BulkRenameModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRename: (operation: {
    type: 'text-number' | 'number-only';
    prefix?: string;
    startNumber: number;
    padding: number;
  }) => void;
  selectedFiles: FileMetadata[];
}

export default function BulkRenameModal({
  isOpen,
  onClose,
  onRename,
  selectedFiles
}: BulkRenameModalProps) {
  const [renameType, setRenameType] = useState<'text-number' | 'number-only'>('text-number');
  const [prefix, setPrefix] = useState('photo');
  const [startNumber, setStartNumber] = useState(1);
  const [padding, setPadding] = useState(2);

  const handleRename = () => {
    onRename({
      type: renameType,
      prefix: renameType === 'text-number' ? prefix : undefined,
      startNumber,
      padding
    });
    onClose();
  };

  const getPreviewName = (index: number, originalName: string) => {
    const extension = originalName.includes('.') ? '.' + originalName.split('.').pop() : '';
    const number = (startNumber + index).toString().padStart(padding, '0');
    
    if (renameType === 'text-number') {
      return `${prefix}${number}${extension}`;
    } else {
      return `${number}${extension}`;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Batch Rename Files</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <Label className="text-sm font-medium">Rename Pattern</Label>
            <RadioGroup value={renameType} onValueChange={(value) => setRenameType(value as 'text-number' | 'number-only')}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="text-number" id="text-number" />
                <Label htmlFor="text-number">Text + Number (e.g., photo01.jpg)</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="number-only" id="number-only" />
                <Label htmlFor="number-only">Number Only (e.g., 001.jpg)</Label>
              </div>
            </RadioGroup>
          </div>

          {renameType === 'text-number' && (
            <div>
              <Label htmlFor="prefix">Text Prefix</Label>
              <Input
                id="prefix"
                value={prefix}
                onChange={(e) => setPrefix(e.target.value)}
                placeholder="Enter prefix text"
              />
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="startNumber">Start Number</Label>
              <Input
                id="startNumber"
                type="number"
                value={startNumber}
                onChange={(e) => setStartNumber(parseInt(e.target.value) || 1)}
                min="0"
              />
            </div>
            <div>
              <Label htmlFor="padding">Zero Padding</Label>
              <Select value={padding.toString()} onValueChange={(value) => setPadding(parseInt(value))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">No padding (1, 2, 3)</SelectItem>
                  <SelectItem value="2">2 digits (01, 02, 03)</SelectItem>
                  <SelectItem value="3">3 digits (001, 002, 003)</SelectItem>
                  <SelectItem value="4">4 digits (0001, 0002, 0003)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label className="text-sm font-medium mb-2 block">Preview ({selectedFiles.length} files)</Label>
            <div className="max-h-32 overflow-y-auto space-y-1 p-3 bg-gray-50 rounded-lg">
              {selectedFiles.slice(0, 5).map((file, index) => (
                <div key={file.id} className="flex items-center justify-between text-sm">
                  <span className="text-gray-600 truncate">{file.name}</span>
                  <span className="text-gray-400 mx-2">→</span>
                  <Badge variant="outline" className="font-mono">
                    {getPreviewName(index, file.name)}
                  </Badge>
                </div>
              ))}
              {selectedFiles.length > 5 && (
                <div className="text-xs text-gray-500 text-center pt-2">
                  ... and {selectedFiles.length - 5} more files
                </div>
              )}
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleRename}>
            Rename {selectedFiles.length} Files
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}