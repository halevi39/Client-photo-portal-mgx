import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AuthService, User } from '@/lib/auth';
import { FileStorageService } from '@/lib/fileStorage';
import { UserPlus, Trash2, Key, User as UserIcon, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';
import { formatBytes } from '@/lib/utils';

export default function AdminUserManagement() {
  const [users, setUsers] = useState<User[]>([]);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showResetModal, setShowResetModal] = useState(false);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  
  // Form states
  const [createForm, setCreateForm] = useState({
    username: '',
    password: '',
    name: ''
  });
  const [newPassword, setNewPassword] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = () => {
    const allUsers = AuthService.getAllUsers();
    setUsers(allUsers);
  };

  const handleCreateUser = () => {
    setError('');
    const result = AuthService.createClientAccount(
      createForm.username,
      createForm.password,
      createForm.name
    );

    if (result.success) {
      toast.success('Client account created successfully');
      setShowCreateModal(false);
      setCreateForm({ username: '', password: '', name: '' });
      loadUsers();
    } else {
      setError(result.error || 'Failed to create account');
    }
  };

  const handleDeleteUser = () => {
    if (!selectedUser) return;

    const result = AuthService.deleteClientAccount(selectedUser.username);
    if (result.success) {
      toast.success('Client account deleted successfully');
      setShowDeleteModal(false);
      setSelectedUser(null);
      loadUsers();
    } else {
      toast.error(result.error || 'Failed to delete account');
    }
  };

  const handleResetPassword = () => {
    if (!selectedUser) return;

    const result = AuthService.resetPassword(selectedUser.username, newPassword);
    if (result.success) {
      toast.success('Password reset successfully');
      setShowResetModal(false);
      setSelectedUser(null);
      setNewPassword('');
    } else {
      toast.error(result.error || 'Failed to reset password');
    }
  };

  const getUserStats = (user: User) => {
    if (user.role === 'admin') return { fileCount: 0, totalSize: 0 };
    
    const userFiles = FileStorageService.getClientFiles(user.id);
    const totalSize = userFiles.reduce((sum, file) => sum + file.size, 0);
    return {
      fileCount: userFiles.length,
      totalSize
    };
  };

  const clients = users.filter(user => user.role === 'client');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">User Management</h2>
        <Button onClick={() => setShowCreateModal(true)}>
          <UserPlus className="h-4 w-4 mr-2" />
          Create Client Account
        </Button>
      </div>

      {/* Users List */}
      <div className="grid gap-4">
        {clients.map(user => {
          const stats = getUserStats(user);
          return (
            <Card key={user.id}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="p-2 bg-blue-100 rounded-full">
                      <UserIcon className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg">{user.name}</h3>
                      <p className="text-sm text-gray-600">@{user.username}</p>
                      <div className="flex items-center space-x-4 mt-1">
                        <Badge variant="secondary">
                          {stats.fileCount} files
                        </Badge>
                        <span className="text-sm text-gray-500">
                          {formatBytes(stats.totalSize)}
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setSelectedUser(user);
                        setShowResetModal(true);
                      }}
                    >
                      <Key className="h-4 w-4 mr-2" />
                      Reset Password
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => {
                        setSelectedUser(user);
                        setShowDeleteModal(true);
                      }}
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Delete
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}

        {clients.length === 0 && (
          <Card>
            <CardContent className="p-12 text-center">
              <UserIcon className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No client accounts</h3>
              <p className="text-gray-600 mb-4">Create your first client account to get started</p>
              <Button onClick={() => setShowCreateModal(true)}>
                <UserPlus className="h-4 w-4 mr-2" />
                Create Client Account
              </Button>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Create User Modal */}
      <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create Client Account</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            {error && (
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
            
            <div>
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                value={createForm.username}
                onChange={(e) => setCreateForm(prev => ({ ...prev, username: e.target.value }))}
                placeholder="Enter username"
              />
            </div>
            
            <div>
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                value={createForm.name}
                onChange={(e) => setCreateForm(prev => ({ ...prev, name: e.target.value }))}
                placeholder="Enter full name"
              />
            </div>
            
            <div>
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                value={createForm.password}
                onChange={(e) => setCreateForm(prev => ({ ...prev, password: e.target.value }))}
                placeholder="Enter password (min 6 characters)"
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreateModal(false)}>
              Cancel
            </Button>
            <Button onClick={handleCreateUser}>
              Create Account
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete User Modal */}
      <Dialog open={showDeleteModal} onOpenChange={setShowDeleteModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Client Account</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                This action cannot be undone. This will permanently delete the client account and all associated files.
              </AlertDescription>
            </Alert>
            
            {selectedUser && (
              <div className="p-4 bg-gray-50 rounded-lg">
                <h4 className="font-semibold">{selectedUser.name}</h4>
                <p className="text-sm text-gray-600">@{selectedUser.username}</p>
                <p className="text-sm text-gray-500 mt-1">
                  {getUserStats(selectedUser).fileCount} files will be deleted
                </p>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteModal(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteUser}>
              Delete Account
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reset Password Modal */}
      <Dialog open={showResetModal} onOpenChange={setShowResetModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reset Password</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            {selectedUser && (
              <div className="p-4 bg-gray-50 rounded-lg">
                <h4 className="font-semibold">{selectedUser.name}</h4>
                <p className="text-sm text-gray-600">@{selectedUser.username}</p>
              </div>
            )}
            
            <div>
              <Label htmlFor="newPassword">New Password</Label>
              <Input
                id="newPassword"
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Enter new password (min 6 characters)"
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowResetModal(false)}>
              Cancel
            </Button>
            <Button onClick={handleResetPassword}>
              Reset Password
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}