import { CloudDatabase } from './cloudDatabase';

export interface User {
  id: string;
  username: string;
  role: 'admin' | 'client';
  name: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
}

export class CloudAuthService {
  private static readonly AUTH_KEY = 'photo_portal_auth';

  static async initializeUsers(): Promise<void> {
    await CloudDatabase.initializeCloudData();
  }

  static async getStoredUsers(): Promise<Record<string, { password: string; user: User }>> {
    await this.initializeUsers();
    const data = await CloudDatabase.loadData();
    return data?.users || {};
  }

  static async saveUsers(users: Record<string, { password: string; user: User }>): Promise<void> {
    const data = await CloudDatabase.loadData();
    if (data) {
      data.users = users;
      data.lastUpdated = new Date().toISOString();
      await CloudDatabase.saveData(data);
    }
  }

  static async login(username: string, password: string): Promise<User | null> {
    const users = await this.getStoredUsers();
    const userConfig = users[username];
    if (userConfig && userConfig.password === password) {
      const authState: AuthState = {
        user: userConfig.user,
        isAuthenticated: true
      };
      localStorage.setItem(this.AUTH_KEY, JSON.stringify(authState));
      return userConfig.user;
    }
    return null;
  }

  static logout(): void {
    localStorage.removeItem(this.AUTH_KEY);
  }

  static getCurrentUser(): User | null {
    try {
      const authData = localStorage.getItem(this.AUTH_KEY);
      if (authData) {
        const authState: AuthState = JSON.parse(authData);
        return authState.isAuthenticated ? authState.user : null;
      }
    } catch (error) {
      console.error('Error parsing auth data:', error);
    }
    return null;
  }

  static isAuthenticated(): boolean {
    return this.getCurrentUser() !== null;
  }

  static async getAllClients(): Promise<User[]> {
    const users = await this.getStoredUsers();
    return Object.values(users)
      .map(config => config.user)
      .filter(user => user.role === 'client');
  }

  static async getAllUsers(): Promise<User[]> {
    const users = await this.getStoredUsers();
    return Object.values(users).map(config => config.user);
  }

  static async createClientAccount(username: string, password: string, name: string): Promise<{ success: boolean; error?: string; loginUrl?: string }> {
    const users = await this.getStoredUsers();
    
    if (users[username]) {
      return { success: false, error: 'Username already exists' };
    }

    if (!username.trim() || !password.trim() || !name.trim()) {
      return { success: false, error: 'All fields are required' };
    }

    if (username.length < 3) {
      return { success: false, error: 'Username must be at least 3 characters' };
    }

    if (password.length < 6) {
      return { success: false, error: 'Password must be at least 6 characters' };
    }

    const clientId = `client_${Date.now()}`;
    users[username] = {
      password: password,
      user: {
        id: clientId,
        username: username,
        role: 'client',
        name: name
      }
    };

    await this.saveUsers(users);
    
    // Generate login URL for the client
    const currentUrl = window.location.origin;
    const loginUrl = `${currentUrl}?client=${username}&temp=${password.substring(0,3)}`;
    
    return { 
      success: true, 
      loginUrl: loginUrl 
    };
  }

  static async deleteClientAccount(username: string): Promise<{ success: boolean; error?: string }> {
    const users = await this.getStoredUsers();
    
    if (!users[username]) {
      return { success: false, error: 'User not found' };
    }

    if (users[username].user.role === 'admin') {
      return { success: false, error: 'Cannot delete admin account' };
    }

    delete users[username];
    await this.saveUsers(users);
    return { success: true };
  }

  static async resetPassword(username: string, newPassword: string): Promise<{ success: boolean; error?: string }> {
    const users = await this.getStoredUsers();
    
    if (!users[username]) {
      return { success: false, error: 'User not found' };
    }

    if (newPassword.length < 6) {
      return { success: false, error: 'Password must be at least 6 characters' };
    }

    users[username].password = newPassword;
    await this.saveUsers(users);
    return { success: true };
  }
}