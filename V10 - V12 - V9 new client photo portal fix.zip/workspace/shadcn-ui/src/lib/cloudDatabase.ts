// Cloud database service using JSONBin.io for persistent storage
export interface CloudUser {
  id: string;
  username: string;
  password: string;
  name: string;
  role: 'admin' | 'client';
  createdAt: string;
}

export interface CloudFileMetadata {
  id: string;
  name: string;
  originalName: string;
  size: number;
  type: string;
  dataUrl: string;
  thumbnailUrl?: string;
  uploadDate: string;
  clientId: string;
  folder?: string;
}

export interface CloudData {
  users: CloudUser[];
  files: CloudFileMetadata[];
}

class CloudDatabaseService {
  private readonly binId = 'YOUR_BIN_ID'; // Replace with actual bin ID
  private readonly apiKey = 'YOUR_API_KEY'; // Replace with actual API key
  private readonly baseUrl = 'https://api.jsonbin.io/v3/b';

  async getData(): Promise<CloudData> {
    try {
      const response = await fetch(`${this.baseUrl}/${this.binId}/latest`, {
        headers: {
          'X-Master-Key': this.apiKey,
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch data');
      }

      const result = await response.json();
      return result.record as CloudData;
    } catch (error) {
      console.error('Error fetching cloud data:', error);
      // Return default data structure if cloud fetch fails
      return {
        users: [
          {
            id: 'admin',
            username: 'admin',
            password: 'admin123',
            name: 'Administrator',
            role: 'admin',
            createdAt: new Date().toISOString(),
          },
        ],
        files: [],
      };
    }
  }

  async saveData(data: CloudData): Promise<boolean> {
    try {
      const response = await fetch(`${this.baseUrl}/${this.binId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'X-Master-Key': this.apiKey,
        },
        body: JSON.stringify(data),
      });

      return response.ok;
    } catch (error) {
      console.error('Error saving cloud data:', error);
      return false;
    }
  }

  async getUsers(): Promise<CloudUser[]> {
    const data = await this.getData();
    return data.users;
  }

  async saveUsers(users: CloudUser[]): Promise<boolean> {
    const data = await this.getData();
    data.users = users;
    return this.saveData(data);
  }

  async getFiles(): Promise<CloudFileMetadata[]> {
    const data = await this.getData();
    return data.files;
  }

  async saveFiles(files: CloudFileMetadata[]): Promise<boolean> {
    const data = await this.getData();
    data.files = files;
    return this.saveData(data);
  }
}

export const cloudDatabase = new CloudDatabaseService();