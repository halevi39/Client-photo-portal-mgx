import { CloudDatabase } from './cloudDatabase';

export interface FileMetadata {
  id: string;
  name: string;
  size: number;
  type: string;
  clientId: string;
  uploadDate: string;
  data: string; // base64 encoded file data
}

export class CloudFileStorageService {
  static async getAllFiles(): Promise<FileMetadata[]> {
    const data = await CloudDatabase.loadData();
    return data?.files || [];
  }

  static async getClientFiles(clientId: string): Promise<FileMetadata[]> {
    const allFiles = await this.getAllFiles();
    return allFiles.filter(file => file.clientId === clientId);
  }

  static async uploadFile(file: File, clientId: string): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = async (e) => {
        try {
          const fileData: FileMetadata = {
            id: `file_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            name: file.name,
            size: file.size,
            type: file.type,
            clientId: clientId,
            uploadDate: new Date().toISOString(),
            data: e.target?.result as string
          };

          const data = await CloudDatabase.loadData();
          if (data) {
            data.files.push(fileData);
            data.lastUpdated = new Date().toISOString();
            await CloudDatabase.saveData(data);
          }

          resolve(fileData.id);
        } catch (error) {
          reject(error);
        }
      };
      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsDataURL(file);
    });
  }

  static async deleteFile(fileId: string): Promise<boolean> {
    try {
      const data = await CloudDatabase.loadData();
      if (data) {
        data.files = data.files.filter(file => file.id !== fileId);
        data.lastUpdated = new Date().toISOString();
        await CloudDatabase.saveData(data);
        return true;
      }
      return false;
    } catch (error) {
      console.error('Error deleting file:', error);
      return false;
    }
  }

  static async updateFileName(fileId: string, newName: string): Promise<boolean> {
    try {
      const data = await CloudDatabase.loadData();
      if (data) {
        const fileIndex = data.files.findIndex(file => file.id === fileId);
        if (fileIndex !== -1) {
          data.files[fileIndex].name = newName;
          data.lastUpdated = new Date().toISOString();
          await CloudDatabase.saveData(data);
          return true;
        }
      }
      return false;
    } catch (error) {
      console.error('Error updating file name:', error);
      return false;
    }
  }

  static downloadFile(fileId: string): void {
    this.getAllFiles().then(files => {
      const file = files.find(f => f.id === fileId);
      if (file) {
        const link = document.createElement('a');
        link.href = file.data;
        link.download = file.name;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    });
  }

  static exportFileList(clientId: string): void {
    this.getClientFiles(clientId).then(files => {
      const fileList = files.map(file => ({
        name: file.name,
        size: file.size,
        uploadDate: file.uploadDate
      }));
      
      const dataStr = JSON.stringify(fileList, null, 2);
      const dataBlob = new Blob([dataStr], { type: 'application/json' });
      
      const link = document.createElement('a');
      link.href = URL.createObjectURL(dataBlob);
      link.download = `file_list_${clientId}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    });
  }
}