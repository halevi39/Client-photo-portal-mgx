export interface FileMetadata {
  id: string;
  name: string;
  originalName: string;
  size: number;
  type: string;
  uploadDate: Date;
  folder?: string;
  clientId: string;
  dataUrl: string; // Base64 encoded file data - ORIGINAL QUALITY
  thumbnailUrl?: string; // Small thumbnail for grid view only
}

export class FileStorageService {
  private static readonly DB_NAME = 'PhotoPortalDB';
  private static readonly DB_VERSION = 1;
  private static readonly STORE_NAME = 'files';
  private static readonly THUMBNAIL_SIZE = 200;

  private static async openDB(): Promise<IDBDatabase> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.DB_NAME, this.DB_VERSION);
      
      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve(request.result);
      
      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        if (!db.objectStoreNames.contains(this.STORE_NAME)) {
          const store = db.createObjectStore(this.STORE_NAME, { keyPath: 'id' });
          store.createIndex('clientId', 'clientId', { unique: false });
        }
      };
    });
  }

  static async uploadFile(file: File, clientId: string, folder?: string): Promise<FileMetadata> {
    // NO SIZE LIMITS - USE INDEXEDDB FOR LARGE STORAGE
    
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = async () => {
        try {
          const originalDataUrl = reader.result as string;
          
          // Create small thumbnail for UI only
          const thumbnailUrl = await this.createThumbnail(originalDataUrl, this.THUMBNAIL_SIZE);

          const fileMetadata: FileMetadata = {
            id: `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            name: file.name,
            originalName: file.name,
            size: file.size,
            type: file.type,
            uploadDate: new Date(),
            folder,
            clientId,
            dataUrl: originalDataUrl, // ORIGINAL QUALITY - NO COMPRESSION
            thumbnailUrl
          };

          await this.saveFile(fileMetadata);
          resolve(fileMetadata);
        } catch (error) {
          reject(error);
        }
      };
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(file);
    });
  }

  private static async createThumbnail(dataUrl: string, size: number): Promise<string> {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d')!;
        
        canvas.width = size;
        canvas.height = size;
        
        // Calculate crop dimensions for square thumbnail
        const { width, height } = img;
        const minDimension = Math.min(width, height);
        const startX = (width - minDimension) / 2;
        const startY = (height - minDimension) / 2;
        
        ctx.drawImage(
          img,
          startX, startY, minDimension, minDimension,
          0, 0, size, size
        );
        
        // Only compress thumbnail for UI performance
        const thumbnailDataUrl = canvas.toDataURL('image/jpeg', 0.8);
        resolve(thumbnailDataUrl);
      };
      img.src = dataUrl;
    });
  }

  static async saveFile(fileMetadata: FileMetadata): Promise<void> {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction([this.STORE_NAME], 'readwrite');
      const store = transaction.objectStore(this.STORE_NAME);
      const request = store.add(fileMetadata);
      
      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve();
    });
  }

  static async getAllFiles(): Promise<FileMetadata[]> {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction([this.STORE_NAME], 'readonly');
      const store = transaction.objectStore(this.STORE_NAME);
      const request = store.getAll();
      
      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve(request.result || []);
    });
  }

  static async getClientFiles(clientId: string): Promise<FileMetadata[]> {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction([this.STORE_NAME], 'readonly');
      const store = transaction.objectStore(this.STORE_NAME);
      const index = store.index('clientId');
      const request = index.getAll(clientId);
      
      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve(request.result || []);
    });
  }

  static async updateFileName(fileId: string, newName: string): Promise<boolean> {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction([this.STORE_NAME], 'readwrite');
      const store = transaction.objectStore(this.STORE_NAME);
      
      const getRequest = store.get(fileId);
      getRequest.onsuccess = () => {
        const file = getRequest.result;
        if (file) {
          file.name = newName;
          const putRequest = store.put(file);
          putRequest.onsuccess = () => resolve(true);
          putRequest.onerror = () => reject(putRequest.error);
        } else {
          resolve(false);
        }
      };
      getRequest.onerror = () => reject(getRequest.error);
    });
  }

  static async bulkRename(fileIds: string[], operation: {
    type: 'prefix' | 'suffix' | 'replace' | 'number';
    value: string;
    find?: string;
    startNumber?: number;
  }): Promise<boolean> {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction([this.STORE_NAME], 'readwrite');
      const store = transaction.objectStore(this.STORE_NAME);
      let updated = false;
      let completed = 0;

      fileIds.forEach((fileId, index) => {
        const getRequest = store.get(fileId);
        getRequest.onsuccess = () => {
          const file = getRequest.result;
          if (file) {
            const extension = file.name.includes('.') ? '.' + file.name.split('.').pop() : '';
            const baseName = file.name.replace(extension, '');

            switch (operation.type) {
              case 'prefix': {
                file.name = operation.value + baseName + extension;
                break;
              }
              case 'suffix': {
                file.name = baseName + operation.value + extension;
                break;
              }
              case 'replace': {
                if (operation.find) {
                  file.name = file.name.replace(new RegExp(operation.find, 'g'), operation.value);
                }
                break;
              }
              case 'number': {
                const number = (operation.startNumber || 1) + index;
                file.name = `${operation.value}${number.toString().padStart(3, '0')}${extension}`;
                break;
              }
            }

            const putRequest = store.put(file);
            putRequest.onsuccess = () => {
              updated = true;
              completed++;
              if (completed === fileIds.length) {
                resolve(updated);
              }
            };
            putRequest.onerror = () => reject(putRequest.error);
          } else {
            completed++;
            if (completed === fileIds.length) {
              resolve(updated);
            }
          }
        };
        getRequest.onerror = () => reject(getRequest.error);
      });
    });
  }

  static async deleteFile(fileId: string): Promise<boolean> {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction([this.STORE_NAME], 'readwrite');
      const store = transaction.objectStore(this.STORE_NAME);
      const request = store.delete(fileId);
      
      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve(true);
    });
  }

  static async downloadFile(fileId: string): Promise<void> {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction([this.STORE_NAME], 'readonly');
      const store = transaction.objectStore(this.STORE_NAME);
      const request = store.get(fileId);
      
      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        const file = request.result;
        if (file) {
          const link = document.createElement('a');
          link.href = file.dataUrl; // ORIGINAL QUALITY DOWNLOAD
          link.download = file.name;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          resolve();
        } else {
          reject(new Error('File not found'));
        }
      };
    });
  }

  static async exportFileList(clientId: string, stripPrefix?: string): Promise<void> {
    const files = await this.getClientFiles(clientId);
    const fileList = files.map(file => {
      let name = file.name;
      if (stripPrefix && name.startsWith(stripPrefix)) {
        name = name.substring(stripPrefix.length);
      }
      return name;
    }).join('\n');

    const blob = new Blob([fileList], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `file_list_${clientId}_${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  static async getStorageInfo(): Promise<{ used: number; estimated: number; fileCount: number; maxStorage: number }> {
    const files = await this.getAllFiles();
    const estimated = files.reduce((total, file) => {
      return total + (file.dataUrl?.length || 0) + (file.thumbnailUrl?.length || 0);
    }, 0);
    
    return {
      used: estimated,
      estimated: Math.round(estimated / 1024 / 1024 * 100) / 100, // MB
      fileCount: files.length,
      maxStorage: 0 // IndexedDB can handle GBs of data
    };
  }

  static async clearAllFiles(): Promise<void> {
    const db = await this.openDB();
    return new Promise((resolve, reject) => {
      const transaction = db.transaction([this.STORE_NAME], 'readwrite');
      const store = transaction.objectStore(this.STORE_NAME);
      const request = store.clear();
      
      request.onerror = () => reject(request.error);
      request.onsuccess = () => resolve();
    });
  }
}