export interface User {
  id: string;
  username: string;
  role: 'admin' | 'client';
  name: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
}

export class AuthService {
  private static readonly AUTH_KEY = 'photo_portal_auth';
  private static readonly USERS_KEY = 'photo_portal_users';

  // Initialize with only admin user - no demo clients
  private static readonly DEFAULT_USERS: Record<string, { password: string; user: User }> = {
    admin: {
      password: 'admin123',
      user: { id: 'admin', username: 'admin', role: 'admin', name: 'Administrator' }
    }
  };

  static initializeUsers(): void {
    const existingUsers = localStorage.getItem(this.USERS_KEY);
    if (!existingUsers) {
      localStorage.setItem(this.USERS_KEY, JSON.stringify(this.DEFAULT_USERS));
    }
  }

  static getStoredUsers(): Record<string, { password: string; user: User }> {
    this.initializeUsers();
    try {
      const data = localStorage.getItem(this.USERS_KEY);
      return data ? JSON.parse(data) : this.DEFAULT_USERS;
    } catch (error) {
      console.error('Error parsing user data:', error);
      return this.DEFAULT_USERS;
    }
  }

  static saveUsers(users: Record<string, { password: string; user: User }>): void {
    localStorage.setItem(this.USERS_KEY, JSON.stringify(users));
  }

  static login(username: string, password: string): User | null {
    const users = this.getStoredUsers();
    const userConfig = users[username];
    if (userConfig && userConfig.password === password) {
      const authState: AuthState = {
        user: userConfig.user,
        isAuthenticated: true
      };
      localStorage.setItem(this.AUTH_KEY, JSON.stringify(authState));
      return userConfig.user;
    }
    return null;
  }

  static logout(): void {
    localStorage.removeItem(this.AUTH_KEY);
  }

  static getCurrentUser(): User | null {
    try {
      const authData = localStorage.getItem(this.AUTH_KEY);
      if (authData) {
        const authState: AuthState = JSON.parse(authData);
        return authState.isAuthenticated ? authState.user : null;
      }
    } catch (error) {
      console.error('Error parsing auth data:', error);
    }
    return null;
  }

  static isAuthenticated(): boolean {
    return this.getCurrentUser() !== null;
  }

  static getAllClients(): User[] {
    const users = this.getStoredUsers();
    return Object.values(users)
      .map(config => config.user)
      .filter(user => user.role === 'client');
  }

  // Add the missing getAllUsers method that AdminUserManagement component needs
  static getAllUsers(): User[] {
    const users = this.getStoredUsers();
    return Object.values(users).map(config => config.user);
  }

  static createClientAccount(username: string, password: string, name: string): { success: boolean; error?: string } {
    const users = this.getStoredUsers();
    
    if (users[username]) {
      return { success: false, error: 'Username already exists' };
    }

    if (!username.trim() || !password.trim() || !name.trim()) {
      return { success: false, error: 'All fields are required' };
    }

    if (username.length < 3) {
      return { success: false, error: 'Username must be at least 3 characters' };
    }

    if (password.length < 6) {
      return { success: false, error: 'Password must be at least 6 characters' };
    }

    const clientId = `client_${Date.now()}`;
    users[username] = {
      password: password,
      user: {
        id: clientId,
        username: username,
        role: 'client',
        name: name
      }
    };

    this.saveUsers(users);
    return { success: true };
  }

  static deleteClientAccount(username: string): { success: boolean; error?: string } {
    const users = this.getStoredUsers();
    
    if (!users[username]) {
      return { success: false, error: 'User not found' };
    }

    if (users[username].user.role === 'admin') {
      return { success: false, error: 'Cannot delete admin account' };
    }

    delete users[username];
    this.saveUsers(users);
    return { success: true };
  }

  static resetPassword(username: string, newPassword: string): { success: boolean; error?: string } {
    const users = this.getStoredUsers();
    
    if (!users[username]) {
      return { success: false, error: 'User not found' };
    }

    if (newPassword.length < 6) {
      return { success: false, error: 'Password must be at least 6 characters' };
    }

    users[username].password = newPassword;
    this.saveUsers(users);
    return { success: true };
  }
}