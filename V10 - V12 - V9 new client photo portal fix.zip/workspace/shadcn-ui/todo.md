# Client Photo Upload & Management Portal - MVP Todo

## Core Files to Create/Modify

### 1. Authentication & User Management
- **src/lib/auth.ts** - Authentication utilities and user management
- **src/components/LoginForm.tsx** - Login form component
- **src/components/ProtectedRoute.tsx** - Route protection wrapper

### 2. File Management Core
- **src/lib/fileStorage.ts** - Local storage-based file management system
- **src/components/FileUpload.tsx** - Drag & drop upload component
- **src/components/FileManager.tsx** - Main file management interface

### 3. UI Components
- **src/components/PhotoGrid.tsx** - Thumbnail grid view
- **src/components/PhotoList.tsx** - List view with file details
- **src/components/PhotoPreview.tsx** - Modal preview for photos
- **src/components/RenameModal.tsx** - Individual and bulk rename functionality

### 4. Pages
- **src/pages/Login.tsx** - Login page
- **src/pages/Dashboard.tsx** - Client dashboard
- **src/pages/AdminDashboard.tsx** - Admin view of all clients

### 5. Configuration
- **index.html** - Update title and metadata

## MVP Implementation Strategy

### Authentication (Simplified)
- Use localStorage for user sessions (demo purposes)
- Pre-configured users: admin, client1, client2
- Simple password validation

### File Storage (Browser-based)
- Use localStorage + IndexedDB for file storage
- Each client has isolated storage namespace
- Support for folders and file metadata

### Core Features Priority
1. ✅ Login system with role-based access
2. ✅ File upload with drag & drop
3. ✅ Grid and list view toggle
4. ✅ Photo preview modal
5. ✅ Individual file rename
6. ✅ Bulk rename with prefix/suffix
7. ✅ Single file download
8. ✅ Export filename list as .txt

### Deferred Features (Post-MVP)
- Bulk zip download (complex in browser)
- Advanced folder management
- Real backend integration

## File Relationships
- Login.tsx → Dashboard.tsx (client) / AdminDashboard.tsx (admin)
- Dashboard components use FileManager as main interface
- FileManager orchestrates PhotoGrid, PhotoList, and modals
- All components share auth context and file storage utilities